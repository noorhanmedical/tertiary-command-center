import { Switch, Route, Redirect, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider, useQuery } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/hooks/use-toast";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider } from "@/components/ui/sidebar";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import SchedulePage from "@/pages/SchedulePage";
import SharedSchedule from "@/pages/shared-schedule";
import PatientDatabasePage from "@/pages/patient-database";
import DocumentsPage from "@/pages/documents";
import BillingPage from "@/pages/billing";
import InvoicesPage from "@/pages/invoices";
import DocumentUploadPage from "@/pages/document-upload";
import AppointmentsPage from "@/pages/appointments";
import OutreachPage from "@/pages/outreach";
import OutreachSchedulerPortalPage from "@/pages/outreach-scheduler-portal";
import TechnicianPortalPage from "@/pages/technician-portal";
import LiaisonPortalPage from "@/pages/liaison-portal";
import AdminOpsPage from "@/pages/admin-ops";
import AdminPage from "@/pages/admin";
import StovetopHeatSettingsPage from "@/pages/stovetop-heat-settings";
import AdminUsersPage from "@/pages/admin-users";
import AdminSettingsCenterPage from "@/pages/admin-settings-center";
import BillingSettingsPage from "@/pages/billing-settings";
import BillingReadinessPage from "@/pages/billing-readiness";
import InvoiceBatchesPage from "@/pages/invoice-batches";
import InvoiceReviewPage from "@/pages/invoice-review";
import InvoiceDeliveryPage from "@/pages/invoice-delivery";
import RemittanceAuditPage from "@/pages/remittance-audit";
import BillingAuditorPage from "@/pages/billing-auditor";
import BillingReportsPage from "@/pages/billing-reports";
import AuditLogPage from "@/pages/audit-log";
import AdminAnalysisJobsPage from "@/pages/admin-analysis-jobs";
import AdminOutboxPage from "@/pages/admin-outbox";
import ScheduleDashboardPage from "@/pages/schedule-dashboard";
import SettingsPage from "@/pages/settings";
import TeamOpsPage from "@/pages/team-ops";
import PlexusTasksPage from "@/pages/plexus-tasks";
import DrivePage from "@/pages/drive";
import DocumentLibraryPage from "@/pages/document-library";
import LoginPage from "@/pages/login";
import { GlobalNav } from "@/components/GlobalNav";
import { TopBanner } from "@/components/TopBanner";
import { GlobalFloatingDock } from "@/components/navigation/GlobalFloatingDock";
import { shouldShowGlobalNav } from "@/lib/navigation/navigationRegistry";
import ClinicWorkflowDemoPage from "@/pages/clinic-workflow-demo";
import CallListAuditPage from "@/pages/call-list-audit";
import PatientDirectoryLiveRoute from "@/pages/patient-directory-live";
import PhysicianPortalPage from "@/pages/physician-portal";
import QualificationPage from "@/pages/qualification";
import OutreachQualificationPage from "@/pages/outreach-qualification";
import PlexusIQPage from "@/pages/plexus-iq";
import TeamMemberPortalsPage from "@/pages/team-member-portals";
import PatientCareSpecialistPortalPage from "@/pages/patient-care-specialist-portal";
import AncillaryCareSpecialistPortalPage from "@/pages/ancillary-care-specialist-portal";
import EngagementCenterPage from "@/pages/engagement-center";
// Slice 1.5: PatientDirectoryLiveRoute import removed — the
// /patient-directory/live route now redirects to /patient-directory.

const SIDEBAR_STYLE = {
  "--sidebar-width": "18rem",
  "--sidebar-width-icon": "3rem",
} as React.CSSProperties;

export type AuthUser = { id: string; username: string; role: string } | null;

function AdminGuard({ user, children }: { user: AuthUser; children: React.ReactNode }) {
  if (!user || user.role !== "admin") {
    return <Redirect to="/home" />;
  }
  return <>{children}</>;
}

function RoleGuard({ user, roles, children }: { user: AuthUser; roles: string[]; children: React.ReactNode }) {
  if (!user || !roles.includes(user.role)) {
    return <Redirect to="/home" />;
  }
  return <>{children}</>;
}

function AuthenticatedApp({ user, onLogout }: { user: AuthUser; onLogout: () => void }) {
  const [currentPath] = useLocation();
  const showGlobalNav = shouldShowGlobalNav(currentPath);
  return (
    <Switch>
      <Route path="/schedule/:id" component={SharedSchedule} />
      <Route>
        <div className="flex flex-col h-screen w-full overflow-hidden">
          <TopBanner user={user} onLogout={onLogout} />
          <GlobalFloatingDock />
          <div className="flex flex-1 min-h-0 min-w-0">
            {showGlobalNav && <GlobalNav user={user} onLogout={onLogout} />}
            <div className="flex flex-col flex-1 min-w-0 min-h-0">
              <div className="flex-1 min-h-0 overflow-auto">
              <Switch>
                <Route path="/">
                  <Redirect to="/home" />
                </Route>
                <Route path="/archive">
                  <Redirect to="/patient-directory" />
                </Route>
                <Route path="/plexus">
                  <Redirect to="/ancillary-documents" />
                </Route>
                <Route path="/home">
                  <SidebarProvider defaultOpen={false} style={SIDEBAR_STYLE}>
                    <Home />
                  </SidebarProvider>
                </Route>
                <Route path="/schedule" component={SchedulePage} />
                {/* Patient EHR — parallel route.
                    Legacy /patient-directory continues to serve
                    PatientDatabasePage so the roster remains the source
                    of truth. /patient-directory/live mounts the new EMR
                    chart surface so clinicians and admins can evaluate
                    parity before any cutover. */}
                <Route path="/patient-directory/live">
                  <RoleGuard user={user} roles={["admin", "clinician"]}>
                    <PatientDirectoryLiveRoute />
                  </RoleGuard>
                </Route>
                <Route path="/patient-directory" component={PatientDatabasePage} />
                <Route path="/patient-database">
                  <Redirect to="/patient-directory" />
                </Route>
                <Route path="/ancillary-documents" component={DocumentsPage} />
                <Route path="/documents">
                  <Redirect to="/ancillary-documents" />
                </Route>
                <Route path="/billing" component={BillingPage} />
                <Route path="/physician-portal">
                  <RoleGuard user={user} roles={["admin", "clinician"]}><PhysicianPortalPage /></RoleGuard>
                </Route>
                <Route path="/invoices">
                  <RoleGuard user={user} roles={["admin", "biller"]}><InvoicesPage /></RoleGuard>
                </Route>
                <Route path="/document-upload" component={DocumentUploadPage} />
                <Route path="/appointments" component={AppointmentsPage} />
                <Route path="/outreach/scheduler/:id" component={OutreachSchedulerPortalPage} />
                <Route path="/outreach-center">
                  <Redirect to="/scheduler-portal" />
                </Route>
                <Route path="/scheduler-portal" component={OutreachPage} />
                <Route path="/outreach">
                  <Redirect to="/scheduler-portal" />
                </Route>
        <Route path="/clinic-workflow-demo" component={ClinicWorkflowDemoPage} />
                <Route path="/technician-portal" component={TechnicianPortalPage} />
                <Route path="/liaison-technician-portal" component={LiaisonPortalPage} />
                <Route path="/liaison-portal">
                  <Redirect to="/liaison-technician-portal" />
                </Route>
        <Route path="/patient-intake" component={QualificationPage} />
        <Route path="/qualification">
          <Redirect to="/patient-intake" />
        </Route>
        <Route path="/visit-patients">
          <SidebarProvider defaultOpen={false} style={SIDEBAR_STYLE}>
            <Home />
          </SidebarProvider>
        </Route>
        <Route path="/visit-qualification">
          <Redirect to="/visit-patients" />
        </Route>
        <Route path="/outreach-patients">
          <SidebarProvider defaultOpen={false} style={SIDEBAR_STYLE}>
            <OutreachQualificationPage />
          </SidebarProvider>
        </Route>
        <Route path="/outreach-qualification">
          <Redirect to="/outreach-patients" />
        </Route>
        <Route path="/plexus-iq">
          <SidebarProvider defaultOpen={false} style={SIDEBAR_STYLE}>
            <PlexusIQPage />
          </SidebarProvider>
        </Route>
        <Route path="/team-member-portals">
          <SidebarProvider defaultOpen={false} style={SIDEBAR_STYLE}>
            <TeamMemberPortalsPage />
          </SidebarProvider>
        </Route>
        <Route path="/patient-care-specialist-portal">
          <SidebarProvider defaultOpen={false} style={SIDEBAR_STYLE}>
            <PatientCareSpecialistPortalPage />
          </SidebarProvider>
        </Route>
        <Route path="/ancillary-care-specialist-portal">
          <SidebarProvider defaultOpen={false} style={SIDEBAR_STYLE}>
            <AncillaryCareSpecialistPortalPage />
          </SidebarProvider>
        </Route>
        <Route path="/engagement-center">
          <SidebarProvider defaultOpen={false} style={SIDEBAR_STYLE}>
            <EngagementCenterPage />
          </SidebarProvider>
        </Route>
        <Route path="/admin/call-list-audit">
          <AdminGuard user={user}>
            <SidebarProvider defaultOpen={false} style={SIDEBAR_STYLE}>
              <CallListAuditPage />
            </SidebarProvider>
          </AdminGuard>
        </Route>
                <Route path="/team-ops" component={TeamOpsPage} />
                <Route path="/task-brain">
                  <Redirect to="/plexus-tasks" />
                </Route>
                <Route path="/plexus-tasks" component={PlexusTasksPage} />
                <Route path="/drive" component={DrivePage} />
                <Route path="/document-library">
                  <AdminGuard user={user}><DocumentLibraryPage /></AdminGuard>
                </Route>
                <Route path="/admin">
                  <AdminGuard user={user}><AdminPage /></AdminGuard>
                </Route>
                <Route path="/admin/stovetop-heat-settings">
                  <AdminGuard user={user}><StovetopHeatSettingsPage /></AdminGuard>
                </Route>
                <Route path="/admin/settings-center">
                  <AdminGuard user={user}><AdminSettingsCenterPage /></AdminGuard>
                </Route>
                <Route path="/admin/billing-settings">
                  <AdminGuard user={user}><BillingSettingsPage /></AdminGuard>
                </Route>
                <Route path="/billing/readiness">
                  <AdminGuard user={user}><BillingReadinessPage /></AdminGuard>
                </Route>
                <Route path="/billing/invoice-batches">
                  <AdminGuard user={user}><InvoiceBatchesPage /></AdminGuard>
                </Route>
                <Route path="/billing/invoice-review">
                  <AdminGuard user={user}><InvoiceReviewPage /></AdminGuard>
                </Route>
                <Route path="/billing/invoice-delivery">
                  <AdminGuard user={user}><InvoiceDeliveryPage /></AdminGuard>
                </Route>
                <Route path="/billing/remittance">
                  <AdminGuard user={user}><RemittanceAuditPage /></AdminGuard>
                </Route>
                <Route path="/billing/auditor">
                  <AdminGuard user={user}><BillingAuditorPage /></AdminGuard>
                </Route>
                <Route path="/billing/reports">
                  <AdminGuard user={user}><BillingReportsPage /></AdminGuard>
                </Route>
                <Route path="/admin/users">
                  <AdminGuard user={user}><AdminUsersPage /></AdminGuard>
                </Route>
                <Route path="/audit-log">
                  <AdminGuard user={user}><AuditLogPage /></AdminGuard>
                </Route>
                <Route path="/admin/analysis-jobs">
                  <AdminGuard user={user}><AdminAnalysisJobsPage /></AdminGuard>
                </Route>
                <Route path="/admin/outbox">
                  <AdminGuard user={user}><AdminOutboxPage /></AdminGuard>
                </Route>
                <Route path="/admin-ops">
                  <AdminGuard user={user}><AdminOpsPage /></AdminGuard>
                </Route>
                <Route path="/dashboard" component={ScheduleDashboardPage} />
                <Route path="/schedule-dashboard">
                  <Redirect to="/dashboard" />
                </Route>
                <Route path="/settings">
                  <AdminGuard user={user}><SettingsPage /></AdminGuard>
                </Route>
                <Route component={NotFound} />
              </Switch>
              </div>
            </div>
          </div>
        </div>
      </Route>
    </Switch>
  );
}

function AppShell() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const { data: user, isLoading, refetch } = useQuery<AuthUser>({
    queryKey: ["/api/auth/me"],
    queryFn: async () => {
      const res = await fetch("/api/auth/me", { credentials: "include" });
      if (res.status === 401) return null;
      if (!res.ok) return null;
      return res.json();
    },
    retry: false,
    staleTime: 5 * 60 * 1000,
  });

  function handleLogin() {
    refetch().then(({ data }) => {
      if (data && (data as AuthUser)?.username === "admin") {
        toast({
          title: "⚠ Default admin account",
          description: "You are using the default admin/admin account. Please change your password in Settings.",
          duration: 8000,
        });
      }
      navigate("/home");
    });
  }

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
    queryClient.clear();
    refetch();
    navigate("/");
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-plexus-navy-950 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-plexus-blue-300 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return <AuthenticatedApp user={user} onLogout={handleLogout} />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AppShell />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
