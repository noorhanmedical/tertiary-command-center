// Canonical query keys for the data hooks layer. All cache reads, writes and
// invalidations go through these so two screens never accidentally use
// different keys for the same endpoint.

export const qk = {
  auth: {
    me: () => ["/api/auth/me"] as const,
  },
  screeningBatches: {
    all: () => ["/api/screening-batches"] as const,
    detail: (id: number | null | undefined) =>
      ["/api/screening-batches", id] as const,
    analysisStatus: (id: number) =>
      ["/api/batches", id, "analysis-status"] as const,
  },
  testHistory: {
    all: () => ["/api/test-history"] as const,
  },
  scheduleDashboard: {
    weekly: (weekStart: string | null | undefined) =>
      ["/api/schedule/dashboard", weekStart || "current"] as const,
  },
  homeStats: {
    today: () => ["/api/home-stats"] as const,
  },
  missionControl: {
    spine: () => ["/api/mission-control/spine"] as const,
  },
  outreach: {
    dashboard: () => ["/api/outreach/dashboard"] as const,
    schedulers: () => ["/api/outreach/schedulers"] as const,
    callsToday: (schedulerUserId: string | null | undefined) =>
      ["/api/outreach/calls/today", schedulerUserId ?? null] as const,
    callsByPatients: (patientIds: number[]) =>
      ["/api/outreach/calls/by-patients", patientIds.join(",")] as const,
  },
  schedulerAssignments: {
    all: () => ["/api/scheduler-assignments"] as const,
  },
  operationalQueue: {
    me: () => ["/api/operational-queue", "me"] as const,
  },
  appointments: {
    byFacility: (facility: string | null | undefined) =>
      ["/api/appointments", facility ?? null] as const,
  },
  plexus: {
    users: () => ["/api/plexus/users"] as const,
    projects: () => ["/api/plexus/projects"] as const,
    projectSummary: (id: number) => ["/api/plexus/projects", id, "summary"] as const,
    myWorkTasks: () => ["/api/plexus/tasks/my-work"] as const,
    sentTasks: () => ["/api/plexus/tasks/sent"] as const,
    urgentTasks: () => ["/api/plexus/tasks/urgent"] as const,
    overdueTasks: () => ["/api/plexus/tasks/overdue"] as const,
    tasksByProject: (projectId: number) =>
      ["/api/plexus/tasks/by-project", projectId] as const,
    unreadCount: () => ["/api/plexus/tasks/unread-count"] as const,
    unreadPerTask: () => ["/api/plexus/tasks/unread-per-task"] as const,
    taskMessages: (id: number) => ["/api/plexus/tasks", id, "messages"] as const,
    taskEvents: (id: number) => ["/api/plexus/tasks", id, "events"] as const,
    patientSearch: (q: string) => ["/api/plexus/patients/search", q] as const,
  },
  invoices: {
    all: () => ["/api/invoices"] as const,
    aging: () => ["/api/invoices/aging"] as const,
    detail: (id: number) => ["/api/invoices", id] as const,
  },
  documentsLibrary: {
    meta: () => ["/api/documents-library/meta"] as const,
    list: (kind: string, surface: string, patientId: string) =>
      ["/api/documents-library", kind, surface, patientId] as const,
    versions: (docId: number) =>
      ["/api/documents-library", docId, "versions"] as const,
  },
  marketingMaterials: {
    all: () => ["/api/marketing-materials"] as const,
  },
} as const;
